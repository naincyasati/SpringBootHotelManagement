package com.hotel.HotelManagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Hotel {
	@Id
	@GeneratedValue
private Integer orderId;
	@Column
private String customerName;
	@Column
private String orderDetail;
	@Column
private long customerBill;
public Hotel() {
	super();
}
public Integer getOrderId() {
	return orderId;
}
public String getCustomerName() {
	return customerName;
}
public String getOrderDetail() {
	return orderDetail;
}
public long getCustomerBill() {
	return customerBill;
}
public void setOrderId(Integer orderId) {
	this.orderId = orderId;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public void setOrderDetail(String orderDetail) {
	this.orderDetail = orderDetail;
}
public void setCustomerBill(long customerBill) {
	this.customerBill = customerBill;
}



}
