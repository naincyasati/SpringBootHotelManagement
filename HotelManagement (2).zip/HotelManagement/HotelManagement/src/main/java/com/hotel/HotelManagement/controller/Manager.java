package com.hotel.HotelManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.HotelManagement.model.Hotel;
import com.hotel.HotelManagement.service.Chef;

@RestController
@RequestMapping("/hotel/api")
public class Manager {
private	Chef chef;
@Autowired
public void setChef(Chef chef) {
	this.chef=chef;
}
@GetMapping("/")
public ResponseEntity<List<Hotel>> getAll() {
	return ResponseEntity.ok(chef.findAll());
}
@PostMapping("/")
public ResponseEntity<Hotel> add(@RequestBody Hotel hotel) {
	return ResponseEntity.ok(chef.save(hotel));
	
}
@GetMapping("/{orderId}")
public ResponseEntity<Hotel> getById(@PathVariable Integer orderId){
	return ResponseEntity.ok(chef.findById(orderId).orElse(null));
	
}
@PutMapping("/")
public ResponseEntity<Hotel> update(@RequestBody Hotel hotel) {
	return ResponseEntity.ok(chef.save(hotel));
	
}
@DeleteMapping("/{orderId}")
public ResponseEntity<Hotel> delete(@PathVariable Integer orderId){
	chef.findById(orderId).ifPresent(chef::delete);
	return ResponseEntity.ok().build();
	
}
}
