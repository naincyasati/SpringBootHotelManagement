package com.hotel.HotelManagement.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.hotel.HotelManagement.model.Hotel;

@Service
public interface Chef extends JpaRepository<Hotel,Integer>{

}
